import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  
  

  constructor(private custSer:CustomerService,private router:Router) { }

  loginCustomer = new FormGroup({
    customerEmail: new FormControl('', [Validators.email]),
    password: new FormControl('')
  });
  signupCustomer=new FormGroup({
    customerName: new FormControl(''),
    customerPhoneNumber: new FormControl(''),
    customerEmail: new FormControl('', [Validators.email]),
    customerUserName: new FormControl(''),
    customerPassword: new FormControl('')
  });

  ngOnInit(): void 
  { 
    this.custSer.getCustomer();
  }
  login() {
    
    let email = this.loginCustomer.get('customerEmail').value;
    let password = this.loginCustomer.get('password').value;
    for(let i=0;i<this.custSer.customerDb.length;i++) 
    {
      if (this.custSer.customerDb[i].customerEmail == email&&this.custSer.customerDb[i].customerPassword==password){     
        this.custSer.tempCustomer=this.custSer.customerDb[i];
        this.custSer.flag=true;
        break;
      }
          
    }
    if (this.custSer.flag) {
      this.router.navigateByUrl("/home");     
    }
  }
    signup()
    {
      let name = this.signupCustomer.get('customerName').value;
      let phoneNo = this.signupCustomer.get('customerPhoneNumber').value;
      let email = this.signupCustomer.get('customerEmail').value;
      let id = this.custSer.customerDb[0].id;
      for(let i=1;i<this.custSer.customerDb.length;i++)
      {
        if(id<this.custSer.customerDb[i].id)
        id=this.custSer.customerDb[i].id;
      }
      id++;
      let userName = this.signupCustomer.get('customerUserName').value;
      let password = this.signupCustomer.get('customerPassword').value;
      let age= 23;
      let tempCustomer:Customer=new Customer(name, phoneNo, email, id, userName,password,age);
      this.custSer.addCustomer(tempCustomer).subscribe(data=>{console.log(data)}); 
      this.router.navigateByUrl("/home"); 
    }
  

}
