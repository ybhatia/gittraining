import { Bus } from './../../../Bus';
import { Booking } from './../../../Booking';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { BookingService } from './../../../booking.service';
import { BusService } from './../../../bus.service';
import { Component, OnInit } from '@angular/core';
import { createOfflineCompileUrlResolver } from '@angular/compiler';

@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrls: ['./generate-report.component.css']
})
export class GenerateReportComponent implements OnInit {
  booking:Booking[]=[];
  bus : Bus[]=[];
  constructor( private busSer : BusService, private bookingSer : BookingService , private router : Router) { }
  viewReport = new FormGroup({
    busId: new FormControl(''),
   // date: new FormControl('')
  })
  ngOnInit(): void {
    this.bookingSer.getBooking();
    this.busSer.getBus();
  }

  viewReports(){
    
  let busId = this.viewReport.get('busId').value;
  //let date=this.generateticket.get('boardingDate').value;
    let k=0;
    for(let i=0;i<this.bookingSer.bookingDb.length ;i++) 
    {
      if (this.bookingSer.bookingDb[i].busId == busId)
      {     
        this.booking[k++]=this.bookingSer.bookingDb[i];
      
        this.bookingSer.flag=true;
       
      }     
    }
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
      if(this.busSer.busDb[i].id == busId)
      {
        this.bus[0] = this.busSer.busDb[i];
        this.busSer.flag = true;
        
      }
      console.log(this.bus[0]);
    }

}
}
