import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  flag1:boolean;
  tempCustomer:any;
  constructor(private custSer:CustomerService,private router:Router) { }
  forgotpassword = new FormGroup({
    customerEmail: new FormControl(''),
    customerUserName: new FormControl(''),
    newPassword: new FormControl(''),
    reNewPassword: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  forgotPassword()
  {
  let customerEmail = this.forgotpassword.get('customerEmail').value;
  let customerUserName=this.forgotpassword.get('customerUserName').value;
  let newPassword=this.forgotpassword.get('newPassword').value;
  let reNewPassword=this.forgotpassword.get('reNewPassword').value;
    for(let i=0;i<this.custSer.customerDb.length;i++) 
    {
      if (this.custSer.customerDb[i].customerEmail == customerEmail)
      {     
        if(this.custSer.customerDb[i].customerUserName==customerUserName)
        {
          if(newPassword==reNewPassword)
          {
            this.custSer.customerDb[i].customerPassword=newPassword;
            this.tempCustomer=this.custSer.customerDb[i];
            this.custSer.updateCustomer(this.custSer.customerDb[i].id,this.tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true;
          }
        }
      }     
    }
    if (this.custSer.flag) 
    {
      this.flag1=true;
      this.router.navigateByUrl("/user");
    }
  }
}
